package com.user.service;

import com.user.entity.User;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class UserServiceImpl  implements  UserService{

    // fake user list
    List<User> list = Arrays.asList(
            new User(1001l, "arpit", "9879879899"),
            new User(1002l, "amit", "8859658788"),
            new User(1003l, "ajay", "77715465499")
    );

    @Override
    public User getUser(Long id) {
        return this.list.stream().filter(user-> user.getUserId().equals(id)).findAny().orElse(null);
    }
}
