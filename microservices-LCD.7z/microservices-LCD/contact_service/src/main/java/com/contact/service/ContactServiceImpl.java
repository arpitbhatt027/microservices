package com.contact.service;

import com.contact.entity.Contacts;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactServiceImpl implements  ContactService{

    // fake list of contacts

    List<Contacts> list = Arrays.asList(
            new Contacts(1l, "arpit@gmail.com","Arpit", 1001l),
            new Contacts(2l, "amit@gmail.com","Amit", 1001l),
            new Contacts(3l, "ajay@gmail.com","Ajay", 1002l),
            new Contacts(4l, "Rahul@gmail.com","Rahul", 1002l),
            new Contacts(5l, "Modi@gmail.com","Modi", 1003l)
    );

    @Override
    public List<Contacts> getContactsOfUser(Long userId) {
        return list.stream().filter(contact->contact.getUserId().equals(userId)).collect(Collectors.toList());
    }
}
